import React from 'react';

import './SpecialMenu.css';

const SpecialMenu = () => (
  <div>
    SpecialMenu
  </div>
);

export default SpecialMenu;
