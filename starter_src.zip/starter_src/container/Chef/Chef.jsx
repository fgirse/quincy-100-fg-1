import React from 'react';

import './Chef.css';

const Chef = () => (
  <div>
    Chef
  </div>
);

export default Chef;
